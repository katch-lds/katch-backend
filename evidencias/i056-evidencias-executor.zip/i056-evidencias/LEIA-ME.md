# Evidências do Executor — I056 (gestão de vagas)

Executor: João Coelho · Branch `joao-coelho/feat/i056-gestao-vagas` · PR #28 · Gerado em 2026-10-29.

| Ficheiro | O que comprova |
| --- | --- |
| `evidencia-api-local.txt` | Pedidos de sucesso e de erro de cada endpoint (6.5.1 a 6.5.8) executados contra a API local sobre PostgreSQL 18, com os resultados de SQL direto e o `operation_log` no fim. |
| `evidencia-api-local.sh` | Script que gerou o ficheiro anterior (para repetir a execução). |
| `build-release.log` | `dotnet build --configuration Release -warnaserror`: 0 avisos, 0 erros. |
| `format-verify.log` | `dotnet format --verify-no-changes`: código de saída 0. |
| `resultados/testes-unitarios.trx` e `testes-unitarios-consola.log` | 730 testes unitários, 730 aprovados. |
| `resultados/testes-integracao.trx` e `testes-integracao-consola.log` | 303 testes de integração, 303 aprovados. |

## Limitações

- Os pedidos à API foram feitos com `curl`, não pelo Swagger UI. As capturas do Swagger UI que a Issue pede
  ainda não estão incluídas.
- A Empresa da execução foi aprovada por SQL, porque o endpoint de aprovação (I055) ainda não está na `main`. O
  interesse em espera e a recusa do Candidato também foram inseridos por SQL.
- A pipeline CI do PR é a fonte oficial dos resultados; os ficheiros acima são a execução local.
