#!/usr/bin/env bash
# Evidência da I056 contra a API local (PostgreSQL 18 descartável, dados fictícios).
PSQL="/c/Program Files/PostgreSQL/18/bin/psql.exe"
API="http://127.0.0.1:5199"
q() { "$PSQL" -h 127.0.0.1 -p 54329 -U katch_test -d katch -X "$@"; }
v() { q -tA -c "$1"; }

curl -s -o /dev/null --retry 60 --retry-delay 2 --retry-connrefused "$API/swagger/v1/swagger.json"

req() { # método rota token [corpo]
  local method="$1" route="$2" token="$3" body="$4"
  echo; echo "\$ $method $route ${body:+$body}"
  local args=(-s -X "$method" -w '\n<- HTTP %{http_code}\n' "$API$route")
  [ -n "$token" ] && args+=(-H "Authorization: Bearer $token")
  # O corpo vai por stdin: nos argumentos, o curl.exe do Windows converte os acentos para a página de código ANSI.
  if [ -n "$body" ]; then
    printf '%s' "$body" | curl "${args[@]}" -H "Content-Type: application/json; charset=utf-8" --data-binary @-
  else
    curl "${args[@]}"
  fi
}
post_json() { printf '%s' "$2" | curl -s -X POST "$API$1" -H "Content-Type: application/json; charset=utf-8" ${3:+-H "Authorization: Bearer $3"} --data-binary @-; }
token_of() { sed -E 's/.*"token":"([^"]+)".*/\1/'; }

LOC=$(v "SELECT id FROM location WHERE name = 'Braga'")
CSHARP=$(v "SELECT id FROM skill WHERE name = 'C#'")
SQLSK=$(v "SELECT id FROM skill WHERE lower(name) = 'sql'")
BEN=$(v "SELECT id FROM benefit WHERE name LIKE 'Seguro de sa%'")
DEMO_JOB=$(v "SELECT id FROM job WHERE status = 'PUBLISHED' ORDER BY id LIMIT 1")
N=$RANDOM

REC=$(post_json /api/auth/recruiters "{\"email\":\"recrutamento.i056.$N@exemplo.pt\",\"password\":\"katch2026\",\"acceptTerms\":true}" | token_of)
post_json /api/recruiter/company "{\"companyName\":\"Lumen Software, Lda.\",\"taxId\":\"5$(printf '%08d' $N)\",\"industry\":\"TECHNOLOGY\",\"address\":\"Rua de Exemplo, 1, 4700-000 Braga\",\"locationId\":\"$LOC\",\"contactEmail\":\"geral@lumen-exemplo.pt\",\"contactPhone\":\"253000000\",\"responsibleName\":\"Responsável Exemplo\"}" "$REC" > /dev/null
CAND=$(post_json /api/auth/candidates "{\"fullName\":\"Teste I056\",\"email\":\"teste.i056.$N@exemplo.pt\",\"phoneNumber\":\"912345678\",\"password\":\"katch2026\",\"locationId\":\"$LOC\",\"acceptTerms\":true}" | token_of)

echo "## Acesso"
req GET /api/recruiter/jobs "$REC"
req GET /api/recruiter/jobs "$CAND"
req GET /api/recruiter/jobs ""
echo; echo "### Aprovação da Empresa por SQL (o endpoint é da I055, ainda não integrada)"
q -q -c "UPDATE company c SET status = 'APPROVED' FROM app_user u WHERE c.recruiter_id = u.id AND u.email = 'recrutamento.i056.$N@exemplo.pt';"

BODY="{\"title\":\"Programador Backend .NET\",\"description\":\"Desenvolvimento e manutenção de APIs REST em ASP.NET Core.\",\"minSalary\":1600.00,\"maxSalary\":2100.00,\"locationId\":\"$LOC\",\"contractType\":\"PERMANENT\",\"workMode\":\"HYBRID\",\"skillIds\":[\"$SQLSK\",\"$CSHARP\"],\"benefitIds\":[\"$BEN\"],\"isUrgent\":true,\"expiresAt\":\"2026-12-31T23:59:00Z\"}"

echo; echo "## 6.5.2 POST /api/recruiter/jobs"
OUT=$(req POST /api/recruiter/jobs "$REC" "$BODY"); echo "$OUT"
JOB=$(echo "$OUT" | sed -nE 's/.*"jobId":"([^"]+)".*/\1/p' | head -1)
req POST /api/recruiter/jobs "$REC" "${BODY/\"minSalary\":1600.00/\"minSalary\":2600.00}"
req POST /api/recruiter/jobs "$REC" "{\"title\":\"\",\"minSalary\":0,\"skillIds\":[],\"locationId\":\"$LOC\",\"contractType\":\"PERMANENT\",\"expiresAt\":\"2020-01-01T00:00:00Z\"}"
req POST /api/recruiter/jobs "$REC" "${BODY/\"contractType\":\"PERMANENT\"/\"contractType\":\"FULL_TIME\"}"

echo; echo "## 6.5.3 PUT /api/recruiter/jobs/{jobId}"
req PUT "/api/recruiter/jobs/$JOB" "$REC" "${BODY/Programador Backend .NET/Programador Backend .NET (Sénior)}"
req PUT "/api/recruiter/jobs/$JOB" "$REC" "${BODY/\"skillIds\":\[\"$SQLSK\",\"$CSHARP\"\]/\"skillIds\":[\"$CSHARP\",\"$CSHARP\"]}"

echo; echo "## 6.5.4 publish / 6.5.5 suspend / 6.5.6 republish"
req POST "/api/recruiter/jobs/$JOB/publish" "$REC"
req POST "/api/recruiter/jobs/$JOB/publish" "$REC"
req POST "/api/recruiter/jobs/$JOB/suspend" "$REC"
req POST "/api/recruiter/jobs/$JOB/suspend" "$REC"
req POST "/api/recruiter/jobs/$JOB/republish" "$REC"
req POST "/api/recruiter/jobs/$JOB/republish" "$REC"
echo "first_published_at / published_at: $(v "SELECT first_published_at || ' / ' || published_at FROM job WHERE id = '$JOB'")"

echo; echo "## Titularidade: vaga de outra Empresa (dados de demonstração)"
req POST "/api/recruiter/jobs/$DEMO_JOB/close" "$REC"
req DELETE "/api/recruiter/jobs/$DEMO_JOB" "$REC"

echo; echo "### Interesse em espera fictício na vaga (por SQL)"
CANDIDATE=$(v "SELECT c.id FROM candidate c JOIN app_user u ON u.id = c.id WHERE u.email = 'candidato01@demo.katch.pt'")
q -q -c "INSERT INTO match (id, candidate_id, job_id, status, candidate_action_at) VALUES (gen_random_uuid(), '$CANDIDATE', '$JOB', 'WAITING', now());"

echo; echo "## 6.5.1 GET /api/recruiter/jobs"
req GET /api/recruiter/jobs "$REC"
echo "SQL: vagas não eliminadas da Empresa = $(v "SELECT count(*) FROM job j JOIN company c ON c.id = j.company_id JOIN app_user u ON u.id = c.recruiter_id WHERE u.email = 'recrutamento.i056.$N@exemplo.pt' AND j.deleted_at IS NULL"); interesses em espera da vaga = $(v "SELECT count(*) FROM match WHERE job_id = '$JOB' AND status = 'WAITING'")"

echo; echo "## 6.5.8 DELETE com interesse / 6.5.7 close"
req DELETE "/api/recruiter/jobs/$JOB" "$REC"
req POST "/api/recruiter/jobs/$JOB/close" "$REC"
echo "Interesse depois de encerrar: $(v "SELECT status FROM match WHERE job_id = '$JOB'")"
req POST "/api/recruiter/jobs/$JOB/close" "$REC"
req PUT "/api/recruiter/jobs/$JOB" "$REC" "$BODY"

echo; echo "## 6.5.8 DELETE sem interesses (só uma recusa do Candidato)"
OUT=$(req POST /api/recruiter/jobs "$REC" "${BODY/Programador Backend .NET/Analista de Dados}")
JOB2=$(echo "$OUT" | sed -nE 's/.*"jobId":"([^"]+)".*/\1/p' | head -1)
q -q -c "INSERT INTO match (id, candidate_id, job_id, status, candidate_action_at) VALUES (gen_random_uuid(), '$CANDIDATE', '$JOB2', 'DECLINED_BY_CANDIDATE', now());"
req DELETE "/api/recruiter/jobs/$JOB2" "$REC"
echo "deleted_at: $(v "SELECT deleted_at FROM job WHERE id = '$JOB2'")"
req PUT "/api/recruiter/jobs/$JOB2" "$REC" "$BODY"
req DELETE "/api/recruiter/jobs/$JOB2" "$REC"
echo "Vagas na lista: $(curl -s "$API/api/recruiter/jobs" -H "Authorization: Bearer $REC" | grep -o '"jobId"' | wc -l)"

echo; echo "## operation_log das duas vagas (RF112)"
q -c "SELECT l.operation, u.email AS autor, CASE l.entity_id WHEN '$JOB' THEN 'vaga 1' ELSE 'vaga 2' END AS vaga
      FROM operation_log l JOIN app_user u ON u.id = l.user_id WHERE l.entity_id IN ('$JOB', '$JOB2') ORDER BY l.id"
